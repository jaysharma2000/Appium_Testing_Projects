import static org.junit.Assert.*;

import java.net.MalformedURLException;
import java.net.URL;
import java.time.Duration;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;

import io.appium.java_client.ios.IOSDriver;
import io.appium.java_client.remote.MobileCapabilityType;

public class RegisterScreenTest {
	protected static IOSDriver driver;

    @Before
    public void setup() throws MalformedURLException {
    	
        DesiredCapabilities caps = new DesiredCapabilities();
        caps.setCapability(MobileCapabilityType.PLATFORM_NAME, "iOS");
        caps.setCapability(MobileCapabilityType.PLATFORM_VERSION, "16.0"); 
        caps.setCapability(MobileCapabilityType.DEVICE_NAME, "iPhone 14 Plus"); 
        caps.setCapability(MobileCapabilityType.AUTOMATION_NAME, "XCUITest");
        caps.setCapability(MobileCapabilityType.APP, "/Users/admin/Library/Developer/CoreSimulator/Devices/67D4D31C-034D-4813-A8AF-327C0E4DADE0/data/Containers/Bundle/Application/069F8414-891E-47A1-B828-1A37D099978E/BookMySlot.app"); 
        caps.setCapability("noReset", true);          

        driver = new IOSDriver(new URL("http://127.0.0.1:4723/"), caps);
        driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
    }
    
    @Test
    public void registerPageTest() throws InterruptedException {
    	System.out.println("Testing the bookmySlot app");
    	
    	WebElement registerButton = driver.findElement(By.id("registerButton"));
    	
    	if(registerButton.isDisplayed()) {
    		System.out.println("The app register button displayed");
    	}else {
    		System.out.println("the app register button not found");
    	}
    	
    	registerButton.click();
    	Thread.sleep(1000);
    	System.out.println("Successfully navigated to register page");
    	
    	
    	WebElement usernameElement = driver.findElement(By.id("userNameReg"));
    	WebElement passwordElement = driver.findElement(By.id("passwordReg"));
    	
    	usernameElement.sendKeys("rahul");
    	passwordElement.sendKeys("12345");
    	
    	WebElement registerBtnElement = driver.findElement(By.id("registerButton"));
    	
    	if(registerBtnElement.isDisplayed()) {
              registerBtnElement.click();
    		
    		System.out.println("registration successfull"); 
    	}else {
    		System.out.println("not able to register");
    	}
    	
    	/*WebElement bookCollectionCountElement = driver.findElement(By.id("bookCollectionCount"));
    	
    	if(bookCollectionCountElement.isDisplayed()) {
    		System.out.println("Number of books added: " +  bookCollectionCountElement.getText());
    	}else {
    		System.out.println("No count found");
    	}*/
    }

    @After
    public void tearDown() {
        if (driver != null) {
            driver.quit();
        }
    }


}
